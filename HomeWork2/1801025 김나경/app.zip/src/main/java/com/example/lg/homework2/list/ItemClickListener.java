package com.example.lg.homework2.list;

import android.view.View;

public interface ItemClickListener {
    public void onItemClick(View v, int index);
}
